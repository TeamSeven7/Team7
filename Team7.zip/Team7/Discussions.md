# Laser Ops - Name of the game
We first need to make a Logo, Ziyad will be taking care of that. He is good at editing and PhotoShop, so take his help in 
designing the game.

Please make the flow of the game, using text or images and we will start with the basic JavaScripting
